 python3 rkvGenRgm.py rkv_watchdog_reg.csv
